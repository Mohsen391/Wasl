---
name: Signal Tech Utility
colors:
  surface: '#f6fafe'
  surface-dim: '#d6dade'
  surface-bright: '#f6fafe'
  surface-container-lowest: '#ffffff'
  surface-container-low: '#f0f4f8'
  surface-container: '#eaeef2'
  surface-container-high: '#e5e9ed'
  surface-container-highest: '#dfe3e7'
  on-surface: '#171c1f'
  on-surface-variant: '#5b4039'
  inverse-surface: '#2c3134'
  inverse-on-surface: '#edf1f5'
  outline: '#8f7067'
  outline-variant: '#e4beb4'
  surface-tint: '#b02f00'
  primary: '#ac2e00'
  on-primary: '#ffffff'
  primary-container: '#d53d06'
  on-primary-container: '#fffbff'
  inverse-primary: '#ffb5a0'
  secondary: '#4e6077'
  on-secondary: '#ffffff'
  secondary-container: '#cee1fc'
  on-secondary-container: '#52647b'
  tertiary: '#006765'
  on-tertiary: '#ffffff'
  tertiary-container: '#13827f'
  on-tertiary-container: '#f3fffd'
  error: '#ba1a1a'
  on-error: '#ffffff'
  error-container: '#ffdad6'
  on-error-container: '#93000a'
  primary-fixed: '#ffdbd1'
  primary-fixed-dim: '#ffb5a0'
  on-primary-fixed: '#3b0900'
  on-primary-fixed-variant: '#862200'
  secondary-fixed: '#d1e4ff'
  secondary-fixed-dim: '#b5c8e3'
  on-secondary-fixed: '#081d30'
  on-secondary-fixed-variant: '#36485e'
  tertiary-fixed: '#96f2ee'
  tertiary-fixed-dim: '#79d6d2'
  on-tertiary-fixed: '#00201f'
  on-tertiary-fixed-variant: '#00504e'
  background: '#f6fafe'
  on-background: '#171c1f'
  surface-variant: '#dfe3e7'
typography:
  headline-2xl:
    fontFamily: Plus Jakarta Sans
    fontSize: 48px
    fontWeight: '800'
    lineHeight: 56px
    letterSpacing: -0.02em
  headline-2xl-mobile:
    fontFamily: Plus Jakarta Sans
    fontSize: 32px
    fontWeight: '800'
    lineHeight: 40px
    letterSpacing: -0.015em
  headline-xl:
    fontFamily: Plus Jakarta Sans
    fontSize: 36px
    fontWeight: '700'
    lineHeight: 44px
    letterSpacing: -0.015em
  headline-xl-mobile:
    fontFamily: Plus Jakarta Sans
    fontSize: 26px
    fontWeight: '700'
    lineHeight: 34px
    letterSpacing: -0.01em
  headline-lg:
    fontFamily: Plus Jakarta Sans
    fontSize: 24px
    fontWeight: '700'
    lineHeight: 32px
    letterSpacing: -0.01em
  headline-md:
    fontFamily: Plus Jakarta Sans
    fontSize: 20px
    fontWeight: '600'
    lineHeight: 28px
  headline-sm:
    fontFamily: Plus Jakarta Sans
    fontSize: 16px
    fontWeight: '600'
    lineHeight: 24px
  body-lg:
    fontFamily: IBM Plex Sans
    fontSize: 18px
    fontWeight: '400'
    lineHeight: 28px
  body-md:
    fontFamily: IBM Plex Sans
    fontSize: 15px
    fontWeight: '400'
    lineHeight: 22px
  body-sm:
    fontFamily: IBM Plex Sans
    fontSize: 13px
    fontWeight: '400'
    lineHeight: 18px
  label-lg:
    fontFamily: IBM Plex Sans
    fontSize: 15px
    fontWeight: '600'
    lineHeight: 20px
    letterSpacing: 0.01em
  label-md:
    fontFamily: IBM Plex Sans
    fontSize: 13px
    fontWeight: '600'
    lineHeight: 16px
    letterSpacing: 0.02em
  label-sm:
    fontFamily: IBM Plex Sans
    fontSize: 11px
    fontWeight: '700'
    lineHeight: 14px
    letterSpacing: 0.05em
  mono-price:
    fontFamily: IBM Plex Sans
    fontSize: 18px
    fontWeight: '700'
    lineHeight: 24px
    letterSpacing: -0.01em
rounded:
  sm: 0.25rem
  DEFAULT: 0.5rem
  md: 0.75rem
  lg: 1rem
  xl: 1.5rem
  full: 9999px
spacing:
  gutter: 1.5rem
  gutter-sm: 1rem
  gutter-lg: 2rem
  margin: 1.5rem
  margin-sm: 1rem
  margin-lg: 3rem
  space-xs: 0.25rem
  space-sm: 0.5rem
  space-md: 1rem
  space-lg: 1.5rem
  space-xl: 2.5rem
---

## Brand & Style

This design system establishes a high-performance visual language tailored for modern consumer technology, hardware retail, and daily utility. The core aesthetic merges precision-engineered physical hardware details with contemporary digital commerce. It balances approachable consumer electronics familiarity with crisp, high-contrast utility using energetic Signal Orange accents.

### Design Movements & Visual Style
- **Engineered Minimalism:** Generous white space, rigorous structural alignments, and purposeful visual density that avoids clutter while prioritizing product specs, connectivity standards, and rapid checkout.
- **Physical Affordance & Tactility:** Surface treatments reflect anodized metals, braided cords, and matte polycarbonate casings. Interactive states feel mechanical, responsive, and tactile.
- **High-Contrast Utility:** Deep ink navy anchors typography and architectural structural blocks, allowing the high-energy signal orange to guide intent, action, and key product differentiators with surgical precision.
- **Cultural & Regional Ergonomics:** Built ground-up to support fluid bilingual layout paradigms (Latin and Arabic script harmony) with explicit conventions for localized commerce, regional fast delivery, and precise localized currency parsing (`KWD 0.000`).

### Target Audience & Emotional Impact
The interface targets busy urban professionals, tech enthusiasts, and mobile-first consumers who require dependable, premium charging and lifestyle gear. The emotional experience delivers unwavering reliability, rapid decision-making, and athletic tech efficiency—instilling trust that hardware purchased will perform without compromise.

## Colors

The color system deploys a strictly functional hierarchy where color conveys mechanical status, attention, or commercial incentives rather than mere decoration.

### Color Roles & Semantics
- **Signal Orange (`#D9400A`):** The primary brand accent and focal point. Reserved strictly for primary call-to-actions, urgent commercial badges (e.g., "Best Seller", "New"), active toggle states, cart checkout thresholds, and signature hardware touches (like USB connector tongue accents).
- **Ink Navy (`#0B1F33`):** The foundational primary text, structural frame, and high-contrast surface color. Provides authoritative weight to headlines, product naming, and prominent inverse contrast sections (such as technical specification trays or dark footer docks).
- **Kuwait Teal (`#0B7F7C`):** The tertiary accent and utility color. Governs logistical confidence, express delivery guarantees, free-shipping threshold completions, in-stock verifications, and non-disruptive success states.
- **Light Grayish Blue Canvas (`#EEF2F6`):** The default screen foundation. Softens the contrast compared to pure harsh blinding white, reducing eye strain and allowing elevated white cards to distinctively rise.
- **Pure White (`#FFFFFF`):** Reserved exclusively for component cards, modal sheets, and active input cavities to provide crisp, clean product showcase areas.
- **Border Gradients & Strokes (`#E2E8F0` / `#CBD5E1`):** Structural containment borders applied at crisp 1px weights to preserve geometry across retina displays.

### Contrast & State Rules
- Signal Orange buttons must always take pure white text (`#FFFFFF`) to satisfy WCAG AA legibility.
- Never use Signal Orange for passive background washes or body text; its efficacy depends on exclusivity.
- Neutral surfaces scale from `#EEF2F6` (canvas) to `#FFFFFF` (card), framed with `#E2E8F0` (subtle border) and `#CBD5E1` (interactive input border).

## Typography

Typography establishes an engineered, technical cadence paired with warm consumer approachability. Display headlines utilize Plus Jakarta Sans for its geometric clarity, wide aperture, and modern architectural presence. Body, interactive controls, technical specs, and numeric data utilize IBM Plex Sans for systematic legibility and engineering pedigree.

### Hierarchy & Application
- **Display Headlines (`headline-2xl`, `headline-xl`):** Used for marketing hero titles and collection takeovers. Styled in Ink Navy (`#0B1F33`), tight letter tracking, and heavy weights for punchy visual authority.
- **Product & Section Titles (`headline-lg`, `headline-md`, `headline-sm`):** Guide categorization, technical specification modules, and product detail view hierarchy.
- **Body Rhythm (`body-lg`, `body-md`, `body-sm`):** Rendered in Ink Navy with opacity scaled between 85% to 70% (`#24374A` to `#4A5D70`) to create a soft reading contrast that does not vibrate against pure white cards.
- **Labels & Microcopy (`label-lg`, `label-md`, `label-sm`):** Strict uppercase formatting for `label-sm` badges to maintain visual density on tight tag elements.

### Currency & Metric Formatting
- The three-decimal Kuwaiti Dinar format (`KWD 0.000`) is treated as a foundational data unit.
- Prices use `mono-price` formatting with tabular numeric figures enabled (`font-variant-numeric: tabular-nums`). The currency symbol ("KWD") is set at 75% relative size with 600 weight, while the integer and 3-decimal fraction maintain full optical prominence (e.g., `KWD 14.750`).

## Layout & Spacing

The layout system employs an intentional fluid-responsive grid system designed for rapid browsing and tactile thumb interactions on handheld devices, expanding to an expansive technical grid on larger screens.

### Grid Framework
- **Mobile (<768px):** 4-column fluid layout, `margin-sm` (1rem / 16px) canvas padding, and `gutter-sm` (1rem / 16px). Product listings default to a 2-column card stack with tight vertical gaps.
- **Tablet (768px - 1024px):** 8-column layout, `margin` (1.5rem / 24px), and `gutter` (1.5rem / 24px). Split panels for configuration and cart overviews.
- **Desktop (>1024px):** 12-column structured grid bounded by a max-width container of `1280px` centered on canvas, `margin-lg` (3rem / 48px), and `gutter-lg` (2rem / 32px).

### Spacing Philosophy
- Spacing follows an 8pt base grid with a 4pt micro-step (`space-xs`: 4px, `space-sm`: 8px, `space-md`: 16px, `space-lg`: 24px, `space-xl`: 40px).
- Internal component paddings are strictly decoupled from external margin/gutter tokens to ensure predictable card containment.
- Dynamic safe areas are strictly adhered to for mobile web checkouts, ensuring bottom fixed navigation bars and floating checkout summaries never collide with mobile gesture indicators.

## Elevation & Depth

Visual hierarchy leverages crisp surface layering and soft, diffused ambient lighting rather than heavy, artificial drop shadows. This reflects physical tech hardware resting on clean workspaces.

### Elevation Levels
- **Canvas Base (Level 0):** The foundational substrate (`#EEF2F6`). Completely flat, zero shadow.
- **Surface Cards (Level 1):** Pure white cards (`#FFFFFF`) framed with a 1px solid border (`#E2E8F0`). Casts a subtle, highly diffused shadow: `0 2px 8px -2px rgba(11, 31, 51, 0.04), 0 4px 16px -4px rgba(11, 31, 51, 0.06)`. This lifts cards gently above the gray-blue substrate without appearing disconnected.
- **Interactive Hover & Floating Controls (Level 2):** Elevated card state upon cursor focus or active touch hold: `0 8px 24px -4px rgba(11, 31, 51, 0.08), 0 2px 6px -1px rgba(11, 31, 51, 0.04)`. Card translates -2px on the Y-axis.
- **Overlays, Drawers & Modals (Level 3):** Flyout carts, quick-spec drawers, and technical filter overlays: `0 20px 48px -8px rgba(11, 31, 51, 0.16)`. Accompanied by a 32% opacity Ink Navy backdrop scrim (`rgba(11, 31, 51, 0.32)`) with a `4px` background blur.

### Hardware Inset Depth
- Input fields, quantity steppers, and spec pill groups utilize an engineered inset depth: a subtle `1px solid #E2E8F0` border with a `#F8FAFC` recessed background to mimic precision-milled port wells.

## Shapes

The design system enforces a balanced shape language: refined modern curvature paired with technical precision. It deliberately avoids overly circular bubble forms in favor of an ergonomic curvature (`roundedness: 2`) that evokes injection-molded casings and smooth silicone bevels.

### Curvature Tokens
- **Base Components (`rounded-md` / 0.5rem / 8px):** Standard inputs, small buttons, thumbnail frames, dropdown menus, and utility tooltips.
- **Cards & Containers (`rounded-lg` / 1rem / 16px):** Primary product cards, summary panels, and modal shells.
- **Featured Surfaces & Hero Blocks (`rounded-xl` / 1.5rem / 24px):** Major showcase tiles, category banner wraps, and bottom sheets.
- **Full Pills (`rounded-full` / 9999px):** Status badges ("Best Seller", "New", "Fast Delivery"), quantity chips, and floating action triggers.

## Components

### Buttons
- **Primary Action (Signal CTA):** Background `#D9400A`, text `#FFFFFF`, border none, radius `0.5rem` (or `rounded-full` for floating actions). Hover: `#BF3606`. Active: `#9E2C04` with a subtle scale transform (`scale(0.98)`).
- **Secondary Action (Ink Utility):** Background `#0B1F33`, text `#FFFFFF`. Hover: `#162E47`. Used for secondary workflows like "Add to Bag" when checkout is already primed.
- **Outline Action:** Background `transparent`, border `1.5px solid #CBD5E1`, text `#0B1F33`. Hover: border `#0B1F33`, background `#F8FAFC`.
- **Ghost Action:** Background `transparent`, text `#0B1F33`. Hover: background `#EEF2F6`.

### Badges & Status Chips
- **Signal Badges ("Best Seller", "New", "Save 20%"):** Pill shape (`rounded-full`), background `#D9400A`, text `#FFFFFF`, font `label-sm`, padding `4px 10px`.
- **Logistics & Delivery Badges ("Same Day Delivery", "In Stock"):** Pill shape, background `rgba(11, 127, 124, 0.10)`, text `#0B7F7C`, border `1px solid rgba(11, 127, 124, 0.25)`, font `label-sm`.
- **Technical Specification Chips (e.g., "65W GaN", "Braided 2m", "MagSafe"):** Background `#F1F5F9`, text `#0B1F33`, border `1px solid #E2E8F0`, radius `0.375rem`, font `label-md`.

### Cards (Product & Content)
- **Product Card Architecture:** Background `#FFFFFF`, border `1px solid #E2E8F0`, radius `1rem`, padding `1rem`. Houses a 1:1 aspect ratio neutral gray container (`#F8FAFC`) for product hardware rendering.
- **Card Header:** Positions signal pill badges at the top-start and a quick-wishlist heart trigger at the top-end.
- **Card Footer:** Displays the localized currency (`KWD 0.000`) on the left and a compact, high-affordance Signal Orange cart add button on the right.

### Input Fields & Steppers
- **Text Inputs:** Height 44px, background `#FFFFFF`, border `1.5px solid #E2E8F0`, radius `0.5rem`, typography `body-md`. Focus: border `#D9400A` with a 3px outer glow ring of `rgba(217, 64, 10, 0.15)`.
- **Quantity Steppers:** Recessed capsule with `#EEF2F6` background, minus/plus icon buttons with tactile active states, and a central tabular digit readout.

### Checkboxes & Radio Buttons
- **Checkbox:** Square box with `0.375rem` radius, border `1.5px solid #CBD5E1`. Checked state: background `#D9400A`, border `#D9400A`, with a sharp white checkmark glyph.
- **Radio Button:** Circular ring with `1.5px solid #CBD5E1`. Selected state: border `#D9400A` with an inner Signal Orange concentric disc.

### Specialized Hardware Components
- **Free Delivery Progress Tracker:** Kuwait Teal bar (`#0B7F7C`) on a `#E2E8F0` track showing threshold progress to unlocked free delivery across Kuwait governorates.
- **Cable Length / Wattage Selectors:** Segmented control tabs with `0.5rem` radius; selected variant features a solid `#0B1F33` fill with `#FFFFFF` text, unselected features a `#FFFFFF` fill with `1px solid #E2E8F0` border.
- **Technical Accordion Trays:** Collapsible drawers for power distribution charts, input/output voltage specs, and device compatibility lists, bordered with `#E2E8F0`.